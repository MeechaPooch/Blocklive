// NOPE

// console.log('injecting vm.js')



// if (!(document.documentElement instanceof SVGElement) && location.pathname.split("/")[1] === "projects") {
//     const scriptElem = document.createElement('script')
//     scriptElem.src = chrome.runtime.getURL("/scripts/vm.js")
//     // document.body.append(scriptElem)
//     if(!!document.head) {
//         document.head.appendChild(scriptElem)
//     } else {
//         document.documentElement.appendChild(scriptElem)
//     }
// }